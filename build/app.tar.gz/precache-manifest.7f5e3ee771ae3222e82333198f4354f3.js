self.__precacheManifest = [
  {
    "revision": "28907c83d92ea9365f3d",
    "url": "/static/css/main.4a503928.chunk.css"
  },
  {
    "revision": "28907c83d92ea9365f3d",
    "url": "/static/js/main.65dcacb2.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "2d0cb9e082f3bc779ff3",
    "url": "/static/css/2.1747bd93.chunk.css"
  },
  {
    "revision": "2d0cb9e082f3bc779ff3",
    "url": "/static/js/2.80c40b85.chunk.js"
  },
  {
    "revision": "f24ed843dd158272e61465dae54b27c9",
    "url": "/index.html"
  }
];