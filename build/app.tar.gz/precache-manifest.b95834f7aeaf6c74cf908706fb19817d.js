self.__precacheManifest = [
  {
    "revision": "56de0c5452c3d121a646",
    "url": "/static/css/main.4a503928.chunk.css"
  },
  {
    "revision": "56de0c5452c3d121a646",
    "url": "/static/js/main.74a4190c.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "c4ea819f51373a09094a",
    "url": "/static/css/2.1747bd93.chunk.css"
  },
  {
    "revision": "c4ea819f51373a09094a",
    "url": "/static/js/2.21b978d8.chunk.js"
  },
  {
    "revision": "dee2ce6a43479a55a24ce944a98ade17",
    "url": "/index.html"
  }
];