self.__precacheManifest = [
  {
    "revision": "71d67f800aabce0c2718",
    "url": "/static/css/main.4a503928.chunk.css"
  },
  {
    "revision": "71d67f800aabce0c2718",
    "url": "/static/js/main.3e3ae64f.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "743a1076b6d2ba6c4c3f",
    "url": "/static/css/2.1747bd93.chunk.css"
  },
  {
    "revision": "743a1076b6d2ba6c4c3f",
    "url": "/static/js/2.7b2e73b9.chunk.js"
  },
  {
    "revision": "4078278a5f2d63722a72583b441eecb6",
    "url": "/index.html"
  }
];